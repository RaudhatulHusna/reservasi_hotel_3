<div class="col-lg-9 mt-2">
<div class="card">
  <div class="card-header">
    Customer
  </div>
  <div class="card-body">
    <h5 class="card-title">Ini adalah bagian customer</h5>
    <p align="center"><img src="https://pixelz.cc/wp-content/uploads/2018/12/costa-adeje-gran-hotel-pool-spain-uhd-4k-wallpaper.jpg" width="800px" hight="200px" class="img-fluid mb-3"></p>
    <p class="card-text">WELCOME TO LUNA HOTEL.</p>
    <p class="card-text">The best hotel reservation wordpress theme.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
</div>