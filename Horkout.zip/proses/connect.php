<?php
$conn = mysqli_connect("localhost","root","","db_hotel");
if(!$conn){
    echo "Gagal koneksi";
}
?>